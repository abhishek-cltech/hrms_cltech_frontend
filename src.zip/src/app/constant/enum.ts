export enum HttpStatus{
    SUCCESS='SUCCESS',
    FAIL='FAIL'
}
export enum RequestMethod{
    POST='POST',
    GET='GET'
}